# CoreShop Store Component

Store Component takes care about Stores and determines which Store the User is in.