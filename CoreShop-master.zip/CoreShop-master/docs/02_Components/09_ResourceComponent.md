# CoreShop Resource Component

Resource Component is the heart of CoreShops Models