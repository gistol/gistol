# CoreShop Shipping Component

Shipping Component takes care about Shipping Rules and Carriers