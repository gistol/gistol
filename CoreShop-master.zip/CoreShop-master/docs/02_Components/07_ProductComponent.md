# CoreShop Product Component

Product Component takes care about Product Models, as well as Product Price Rules, Specific Product Rules and Price Calculators.