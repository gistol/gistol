# CoreShop Customer Component

Customer Component takes care about Customer Models.