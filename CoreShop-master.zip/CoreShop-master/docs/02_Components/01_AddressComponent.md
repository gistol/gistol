# CoreShop Address Component

Address Component holds Address Information and takes care about formatting addresses, as well as determining which Country the User comes from.