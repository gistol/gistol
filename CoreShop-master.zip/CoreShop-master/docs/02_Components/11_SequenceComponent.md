# CoreShop Sequence Component

Sequence Component creates new Numbers for Orders/Quotes/Invoices etc.