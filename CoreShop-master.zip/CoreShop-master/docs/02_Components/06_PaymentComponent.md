# CoreShop Payment Component

Payment Component takes care about Payment Informations.