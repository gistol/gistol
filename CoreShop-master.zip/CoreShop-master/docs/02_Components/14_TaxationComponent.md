# CoreShop Taxation Component

Taxation Component takes about Taxes and calculating them.