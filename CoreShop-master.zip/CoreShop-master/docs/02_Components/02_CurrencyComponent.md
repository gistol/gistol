# CoreShop Currency Component

Currency Component takes care about Currency, Currency Conversion and Formatting, as well as determining which Currency is the current one.