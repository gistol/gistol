# CoreShop Order Component

Order Component takes care about Cart, Orders and Qoutes. All of this three share one Interface "ProposalInterface"/"ProposalItemInterface".