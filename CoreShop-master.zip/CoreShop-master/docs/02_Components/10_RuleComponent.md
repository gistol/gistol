# CoreShop Rule Component

Rule Component is the base-component for all Rule related stuff in CoreShop. For example:
 - CoreShop Cart Price Rules
 - Product Price Rule
 - Product Specific Price Rule
 - Shipping Rule
 - Mail Rule