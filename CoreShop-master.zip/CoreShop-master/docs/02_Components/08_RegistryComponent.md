# CoreShop Registry Component

Registry Component takes care about Service Registries and Prioritized Service Registration which are used basically everywhere in CoreShop.