# CoreShop Index Component

Index Component takes care about storing Meta-Informations for Indexes and Filters.