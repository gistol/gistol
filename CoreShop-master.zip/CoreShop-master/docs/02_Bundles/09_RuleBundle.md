# CoreShop Rule Bundle

Base Bundle for all Rule related stuff.