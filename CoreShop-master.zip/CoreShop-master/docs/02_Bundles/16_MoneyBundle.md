# CoreShop Money Bundle

    - adds a new field for Currency values to Pimcore, which then translate them to integers

TBD
