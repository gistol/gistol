# CoreShop Configuration Bundle

    - Doctrine Mappings

