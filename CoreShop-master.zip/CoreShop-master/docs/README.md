Welcome to the CoreShop Documentation!

 * [Website](https://www.coreshop.org)
 * [API-Documentation](https://api.coreshop.org/2.0.0)
 * [Github](https://github.com/coreshop/CoreShop)