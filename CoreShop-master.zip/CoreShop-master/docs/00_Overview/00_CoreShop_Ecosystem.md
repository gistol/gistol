# CoreShop Ecosystem

The following list of resources should show you where to get information about CoreShop and whats going on in the whole ecosystem. 

* [CoreShop Documentation](../README.md)
* [CoreShop at Github](https://github.com/coreshop/CoreShop)
* [CoreShop API](https://apiv2.coreshop.org)
* [CoreShop at Packagist](https://packagist.org/packages/coreshop/core-shop)
* [CoreShop at Gitter](https://gitter.im/coreshop/coreshop)
* [Pimcore](https://www.pimcore.org)