# CoreShop Index and Filter

This guide should lead you through how CoreShop handles Indices and Filters.

1. [Indices](./01_Index)
2. [Filters](./02_Filter)
