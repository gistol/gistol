# CoreShop Order Workflow

CoreShop uses [Pimcore Workflow](https://pimcore.com/docs/5.0.x/Workflow_Management/index.html) to handle Order States.
