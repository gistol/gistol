# CoreShop Shipment

CoreShop comes with an Shipment (Delivery Slip) creation feature. This means, it can create Shipments for Orders based on Workflow States.