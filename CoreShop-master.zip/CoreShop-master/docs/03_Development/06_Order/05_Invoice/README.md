# CoreShop Invoice

CoreShop comes with an Invoice creation feature. This means, it can create Invoices for Orders based on Workflow States.