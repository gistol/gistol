# CoreShop Order Events

TODO