# CoreShop Customer

This guide should lead you through how CoreShop handles Customer Information.

 1. [Create, Read, Update, Delete](./01_CRUD.md)
 2. [Customer Context](./02_Context.md)
 3. [Registration Service](./03_Registration_Service.md)