# CoreShop Notification Rule Custom Actions

 - [Click here to see how you can add custom Actions](../01_Extending_Guide/04_Extending_Rule_Actions.md)