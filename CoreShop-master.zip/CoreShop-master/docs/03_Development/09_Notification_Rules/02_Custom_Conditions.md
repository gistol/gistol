# CoreShop Notification Rule Custom Conditions

 - [Click here to see how you can add custom Conditions](../01_Extending_Guide/05_Extending_Rule_Conditions.md)