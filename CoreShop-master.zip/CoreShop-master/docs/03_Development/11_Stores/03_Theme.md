# CoreShop Stores Theming

CoreShop Stores are designed to allow different Themes. Therefore you can have a true Multi-Store Environment with different Themes.

To create a new Theme, simply add a new Store, give the theme a Name and:

 - Go to your AppBundle/Resources directory and create a new folder called "themes"
 - Inside there, you create a new folder called like your theme Name within the Store Configuration
 - CoreShop now replaces all files found in there with them from the "default" theme.
