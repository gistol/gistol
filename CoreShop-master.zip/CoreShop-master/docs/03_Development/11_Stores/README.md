# CoreShop Stores

CoreShop Stores help you create a multi-store based eCommerce System with different Themes across these Stores.

 - [Create, Read, Update, Delete](./01_CRUD.md)
 - [Store Context](./02_Context.md)
 - [Theming](./03_Theme.md)