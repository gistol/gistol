# CoreShop eCommerce Framework Bridge

This is just an Idea and nothing conrete has been implemented.