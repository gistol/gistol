# CoreShop Store Front

The CoreShop Store Front (FrontendBundle) comes with a default implementation and is designed to show you how to work with
the CoreShop Framework.

 - [Controllers](./01_Controllers.md)