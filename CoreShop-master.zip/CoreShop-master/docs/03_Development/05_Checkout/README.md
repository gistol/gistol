# CoreShop Checkout

This guide should lead you through how CoreShop handles the Checkout.

 - [Checkout Manager](./01_Checkout_Manager.md)
 - [Checkout Step](./02_Checkout_Step.md)
