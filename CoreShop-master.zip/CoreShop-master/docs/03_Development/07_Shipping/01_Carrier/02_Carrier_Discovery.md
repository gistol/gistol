# CoreShop Carrier Discovery

CoreShop uses a Service to discover available Carriers for a given Shippable. These Service implements the Interface ```CoreShop\Bundle\ShippingBundle\Discover\ShippableCarriersDiscoveryInterface```.
The Interface is implemented by Service with ID ```coreshop.carrier.discovery```