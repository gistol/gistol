# CoreShop Carrier

This guide should lead you through how CoreShop handles Carriers.

 - [Create, Read, Update, Delete](./01_CRUD.md)
 - [Carrier Discovery](./02_Carrier_Discovery.md)
 - [Price Calculation](./03_Price_Calculation.md)