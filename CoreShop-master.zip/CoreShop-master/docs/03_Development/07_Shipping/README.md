# CoreShop Shipping

This guide should lead you through how CoreShop handles Shipping and Shipping Calculation.

 - [Carriers](./01_Carrier.md)
 - [Shipping Rules](./02_Shipping_Rules.md)