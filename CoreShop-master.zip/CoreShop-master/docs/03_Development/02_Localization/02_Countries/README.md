# CoreShop Countries

> CoreShop is a multi-country able eCommerce Framework. Therefore it is possible to create and use different Countries.

1. [Create, Update, Read, Delete](./01_CRUD.md)
2. [Country Context](./03_Context.md)