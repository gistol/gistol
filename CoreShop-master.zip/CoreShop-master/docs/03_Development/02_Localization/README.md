# CoreShop Localization

CoreShop provides you with a set of tools for better localization of your eCommerce. These tools exist of following parts:

 - [Currencies](./01_Currencies)
 - [Countries](./02_Countries)
 - [States](./03_States)
 - [Zones](./04_Zones)
 - [Taxes](./05_Taxes)