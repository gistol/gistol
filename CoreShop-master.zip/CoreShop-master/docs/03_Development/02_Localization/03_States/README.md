# CoreShop States

1. [Create, Update, Read, Delete](./01_CRUD.md)