# CoreShop Zones

1. [Create, Update, Read, Delete](./01_CRUD.md)