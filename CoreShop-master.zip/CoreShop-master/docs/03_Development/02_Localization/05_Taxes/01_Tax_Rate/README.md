# CoreShop Tax Rate

> The Tax Rate only represents a single Tax Rate Number. For example: 20%.

1. [Create, Update, Read, Delete](./01_CRUD.md)