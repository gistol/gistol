# CoreShop Taxes

> Taxes are divided into Tax Rates and Tax Rules. Tax Rules are responsible for the real Tax Rate determination based on Country and State.

1. [Tax Rates](./01_Tax_Rate.md)
1. [Tax Rules](./01_Tax_Rule.md)