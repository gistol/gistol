# CoreShop Tax Rule

> The Tax Rule handles different Taxes based on Country and State.

1. [Create, Update, Read, Delete](./01_CRUD.md)