# CoreShop Currencies

> CoreShop is a multi-currency able eCommerce Framework. Therefore it is possible to create and use different currencies.

1. [Create, Update, Read, Delete](./01_CRUD.md)
2. [Exchange Rates](./02_Exchange_Rates.md)
2. [Currency Context](./03_Context.md)