# CoreShop Carrier Distribution Report

![Carrier Distribution](img/carriers.png)