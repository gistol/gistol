# CoreShop Carts Report

![Carts Report](img/carts.png)