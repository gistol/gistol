# CoreShop Customers Report

![Customers Report](img/customers.png)