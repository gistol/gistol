# CoreShop Products Report

![Products Report](img/products.png)