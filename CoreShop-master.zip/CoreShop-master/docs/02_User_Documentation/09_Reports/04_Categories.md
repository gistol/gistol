# CoreShop Categories Report

![Categories Report](img/categories.png)