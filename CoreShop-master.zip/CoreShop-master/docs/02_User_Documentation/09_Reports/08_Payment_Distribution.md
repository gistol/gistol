# CoreShop Payment Distribution Report

![Payment Distribution](img/payments.png)