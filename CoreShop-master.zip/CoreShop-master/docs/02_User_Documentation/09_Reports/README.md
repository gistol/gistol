# CoreShop Reports

 * [Sales](./01_Sales.md)
 * [Carts](./02_Carts.md)
 * [Products](./03_Products.md)
 * [Categories](./04_Categories.md)
 * [Customers](./05_Customers.md)
 * [Available Quantities](./06_Available_Quantities.md)
 * [Carrier Distribution](./07_Carrier_Distribution.md)
 * [Payment Distribution](./08_Payment_Distribution.md)