# CoreShop Available Quantities Report

![Quantities Report](img/quantities.png)