# CoreShop Sales Report

![Sales Report](img/sales.png)