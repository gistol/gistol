CoreShop can use GeoIP to locate visitors countries using IP-Addresses.

CoreShop uses the already existing Pimcore GeoIP Database located in: ```/var/config/GeoLite2-City.mmdb```