# CoreShop Localization

 * [Countries](./01_Countries.md)
 * [States](./02_States.md)
 * [Zones](./03_Zones.md)
 * [Currencies](./04_Currencies.md)
 * [Taxes](./05_Taxes.md)
 * [TaxRules](./06_TaxRules.md)