# CoreShop Zone

A Country consists of following values:

 - Name
 - Active

Zones are basically just a group of countries and can be used for Price Rules and Shipping Rules.

![Zones](img/zones.png)