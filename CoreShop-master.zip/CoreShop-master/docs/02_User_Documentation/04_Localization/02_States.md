# CoreShop State

A State/County consists of following values:

 - Name
 - Iso Code
 - Active
 - Country

![States](img/states.png)