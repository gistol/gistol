# CoreShop Taxes

A Tax Rate consists of following values:

 - Localized Name: This name can also be seen in the cart or on invoices
 - Rate: Tax Rate, for example 20%
 - Active

Taxes are going to be used in Tax Rules.

![Taxes](img/taxes.png)
