# CoreShop Country

A Country consists of following values:

 - Name
 - ISO-Code
 - Active: Determines if customers from this country are able to purchase from your store
 - Use Store default Currency: If checked, your stores default currency will be applied to the country
 - Currency
 - Zone
 - Stores: Determines for which Stores this Country is available.

![Countries](img/countries.png)