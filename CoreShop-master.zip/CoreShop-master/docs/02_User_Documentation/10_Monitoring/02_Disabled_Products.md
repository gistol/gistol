# CoreShop Disabled Products Monitoring Report

![Disabled Products](img/disabled-products.png)