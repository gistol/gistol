# CoreShop Out of Stock Monitoring Report

![Out of Stock Products](img/out-of-stock-products.png)