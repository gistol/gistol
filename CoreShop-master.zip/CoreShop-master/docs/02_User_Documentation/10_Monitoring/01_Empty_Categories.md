# CoreShop Empty Categories Monitoring Report

![Empty Categories](img/empty-categories.png)