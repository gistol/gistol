# CoreShop Price Rules

- [Cart Price Rules](./01_Cart_Price_Rules.md)
- [Product Price Rules](./02_Product_Price_Rules.md)
- [Specific Product Prices](./03_Specific_Product_Prices.md)