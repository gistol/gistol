# CoreShop Catalog

 * [Products](./01_Products.md)
 * [Product Variants](./02_Product_Variants.md)
 * [Categories](./03_Categories.md)